<?php 
    session_start();
    $conn = mysqli_connect('localhost','root','','ipt_project');

    if(!isset($_SESSION['edit'])){
         
    }
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Home</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    body {
      background-image: url("../ipt_project/bg_color.jpg");
      background-size: cover;
    }
  </style>
<body>
<br><br>

<div class="container">
  <h2 style="font-weight: bold; font-size: 35px">InspiroSearch, Inspires and Discovers</h2><br>

      <div class="row">
      <div class="col-md-6">
        <h3>About InspiroSearch</h3>
        <p style= "font-size: 17px">InspiroSearch is a versatile web application designed to provide users with an enriching experience by generating random quotes and 
          querying search engines simultaneously. It combines the power of inspiration and information retrieval into a single platform. 
          InspiroSearch is a web-based tool that harnesses the concept of serendipity by generating random quotes that can inspire, motivate, 
          or provoke thought in users. This application goes beyond just offering quotes; it also allows users to simultaneously perform 
          searches on popular search engines, providing a seamless and efficient way to explore related topics or dive deeper into subjects 
          of interest. With InspiroSearch, users can discover a diverse range of quotes from various categories, such as success, happiness, 
          love, leadership, and more, helping to broaden their perspectives and ignite new ideas.
        </p>
      </div>
      <div class="col-md-6">
      <img src="../ipt_project/inspirosearch.png" alt="Your Image" class="img-responsive" width="400" height="100" style="display:block; margin: 0 auto;">
      </div>
    </div>
    <br><br>

    <div class="row">
      <div class="col-md-6">
        <h3>The Developers of "InspiroSearch"</h3>
        <p style= "font-size: 17px">Sigron Niño Rios and Karl Christian Saycon, two brilliant and devoted developers who co-founded InspiroSearch, came up with the 
          idea. The creator of InspiroSearch, Sigron Nio Rios, is a driven software engineer with a wealth of knowledge in building web 
          pplications and a deep interest in user experience design. Karl Christian Saycon, one of the co-founders, has a plethora of 
          xperience in software development, notably in the fields of backend systems and database administration. His abilities have played 
          a key role in guaranteeing the stability and dependability of InspiroSearch. By diligently working on InspiroSearch, Sigron and Karl 
          have made it a platform that is truly complete and user-centric by incorporating user feedback and adding new features. The devotion 
          and expertise of Sigron Niño Rios and Karl Christian Saycon have resulted in the development of InspiroSearch, a cutting-edge web 
          tool that effortlessly integrates the power of inspiring quotes and search capability to provide users a unique and engaging 
          experience.
        </p>
      </div>
      <div class="col-md-6">
        <img src="../ipt_project/profiles.jpg" alt="Your Image" class="img-responsive">
      </div>
    </div>
    <br><br>

    <a class= "btn btn-primary" href="view_user.php">View Users</a>
    <br><br>
    <a class= "btn btn-success" href="quotes_api.php">Get Random Quote</a>
    <br><br>
    <a class= "btn btn-info" href="websearch_api.php">Web Search</a>
    <br><br>
    <a class= "btn btn-danger" href="logout_form.php">Logout</a>
    <br><br><br><br>
</div>

</body>
</html>
