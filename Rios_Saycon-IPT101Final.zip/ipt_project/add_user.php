<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<body>
  <style>
    body {
        background-image: url("../ipt_project/bg_color.jpg");
        background-size: cover;
    }
</style>
</head>
<body>
<br><br>

<div class="container">
<h2>New User</h2><br>
<form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
        <label for="email">Name:</label>
        <input type="text" class="form-control" placeholder="Name" name="name">
    </div>
    <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" class="form-control" placeholder="Enter email" name="email">
    </div>
    <div class="form-group">
        <label for="pwd">Password:</label>
        <input type="password" class="form-control" placeholder="Enter password" name="password">
    </div>
    <br>
    <input type="submit" name="insert-btn" class="btn btn-primary"/>
    
</form>

<?php
    $conn = mysqli_connect('localhost', 'root', '', 'ipt_project');

    if (isset($_POST['insert-btn'])) {
        $user_name = $_POST['name'];
        $user_email = $_POST['email'];
        $user_password = $_POST['password'];

        $check_query = "SELECT * FROM web WHERE email='$user_email'";
        $check_result = mysqli_query($conn, $check_query);
        if (mysqli_num_rows($check_result) > 0) {
            echo "User already exists.";
        } else {
            $insert_query = "INSERT INTO web (name, email, password) VALUES ('$user_name', '$user_email', '$user_password')";
            $insert_result = mysqli_query($conn, $insert_query);
            if ($insert_result) {
                header("Location: login_form.php");
                exit(); 
            } else {
                echo "Failed to create user, please try again.";
            }
        }
    }
?>



</div>

</body>
</html>
