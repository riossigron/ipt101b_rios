<!DOCTYPE html>
<html lang="en">
<head>
  <title>View</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.4/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/js/bootstrap.bundle.min.js"></script>
  <style>
    body {
      background-image: url("../ipt_project/bg_color.jpg");
      background-size: cover;
    }
  </style>
</head>
<body>
<br><br>
<div class="container">
  <h2>View Users</h2>
  <?php
    $conn = mysqli_connect('localhost', 'root', '', 'ipt_project');
    if(isset($_GET['del'])){
        $del_id = $_GET['del'];
        $delete = "DELETE FROM web WHERE id ='$del_id'";
        $run_delete = mysqli_query($conn, $delete);
        if($run_delete === true){
            echo "";
        }else{
            echo "";
        }
    }
  ?>
  <br>
  <table class="table">
    <thead>
      <tr>
        <th>ID</th>
        <th>Username</th>
        <th>Email</th>
        <th>Password</th>
        <th></th>
        <th></th>
        <th></th>
      </tr>
    </thead>
    <tbody>
      <?php
      $select = "SELECT * FROM web";
      $run = mysqli_query($conn, $select);
      while($row_user = mysqli_fetch_array($run)){
          $user_id = $row_user['id'];
          $user_name = $row_user['name'];
          $user_email = $row_user['email'];
          $user_password = $row_user['password'];
      ?>
      <tr>
        <td><strong><?php echo $user_id; ?></strong></td>
        <td><strong><?php echo $user_name; ?></strong></td>
        <td><strong><?php echo $user_email; ?></strong></td>
        <td><strong><?php echo str_repeat("*", strlen($user_password)); ?></strong></td>
        <td><a class="btn btn-danger" href="view_user.php?del=<?php echo $user_id; ?>">Delete</a></td>
        <td><a class="btn btn-success" href="edit_user.php?edit=<?php echo $user_id; ?>">Edit</a></td>
        <td><a class="btn btn-primary" href="index.php">Home</a></td>
      </tr>
      <?php } ?>
    </tbody>
  </table>
</div>

</body>
</html>
