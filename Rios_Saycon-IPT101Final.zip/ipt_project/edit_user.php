<!DOCTYPE html>
<html lang="en">
<head>
  <title>Update</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  <style>
    body {
      background-image: url("../ipt_project/bg_color.jpg");
      background-size: cover;
    }
  </style>
<body>
<br><br>

<div class="container">
  <h2>User</h2><br>

  <?php
        $conn = mysqli_connect('localhost','root','','ipt_project');
        $user_name = '';
        $user_email = '';
        $user_password = '';

        if(isset($_GET['edit'])){
            $edit_id = $_GET['edit'];
            $select = "SELECT * FROM web WHERE id = '$edit_id'";
            $run = mysqli_query($conn,$select);
            $row_user = mysqli_fetch_array($run);
            $user_name = $row_user['name'];
            $user_email = $row_user['email'];
            $user_password = $row_user['password'];
        }
        
  ?>

  <form action="" method="post" enctype="multipart/form-data">
    <div class="form-group">
      <label for="email">Name:</label>
      <input type="text" class="form-control" value="<?php echo $user_name ?>" placeholder="Name" name="name">
    </div>
    <div class="form-group">
      <label for="email">Email:</label>
      <input type="email" class="form-control" value="<?php echo $user_email ?>" placeholder="Enter email" name="email">
    </div>
    <div class="form-group">
      <label for="pwd">Password:</label>
      <input type="password" class="form-control" value="<?php echo $user_password ?>" placeholder="Enter password" name="password">
    </div>
    <br>
    <input type="submit" name="insert-btn" class="btn btn-primary"/>
  </form>
  <br>

  <?php
    $conn = mysqli_connect('localhost','root','','ipt_project');

    if(isset($_POST['insert-btn'])){
        $euser_name = $_POST['name'];
        $euser_email = $_POST['email'];
        $euser_password = $_POST['password'];

        $update = "UPDATE web SET name = '$euser_name', email = '$euser_email', password = '$euser_password' WHERE id = '$edit_id'";

        $run_update = mysqli_query($conn,$update);
        if($run_update === true){
            // Redirect to view_user.php after successful update
            header("Location: view_user.php");
            exit();
        }else {
            echo "Failed, try again...";
        }
    }
  ?>
</div>

</body>
</html>
