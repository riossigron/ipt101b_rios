<?php

$curl = curl_init();

curl_setopt_array($curl, [
    CURLOPT_URL => "https://quotes15.p.rapidapi.com/quotes/random/",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => [
        "X-RapidAPI-Host: quotes15.p.rapidapi.com",
        "X-RapidAPI-Key: a5e279f135msh297719df972ddcfp1b4112jsn628b175192fd"
    ],
]);

$response = curl_exec($curl);
$err = curl_error($curl);

curl_close($curl);

if ($err) {
    echo "cURL Error #:" . $err;
} else {
    $quote = json_decode($response, true);
    ?>

    <!DOCTYPE html>
    <html lang="en">
    <head>
        <title>Random Quote</title>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
        <style>
            body {
                background-image: url("../ipt_project/bg_color.jpg");
                background-size: cover;
            }
            
        </style>
    </head>
    <body>
    <br><br>
    <div class="container">
        <h2>Random Quotes</h2><br>
        <div class="panel panel-default">
            <div class="panel-heading" style="background-color: #337ab7; color: #fff; font-weight: bold; font-size: 17px">Quote of the Day</div>
            <div class="panel-body" style="font-size: 20px;"><?php echo $quote['content']; ?></div>
        </div>
        <br>
        <a class="btn btn-primary" href="index.php">Home</a>
        <a class="btn btn-success" href="quotes_api.php">Regenerate</a>
    </div>
    </body>
    </html>
<?php
}
?>
