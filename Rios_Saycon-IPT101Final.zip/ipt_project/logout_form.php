<?php 
    session_start();
    if(isset($_SESSION['email'])){
        unset($_SESSION['email']);
        session_destroy();
    }
    $conn = mysqli_connect('localhost','root','','ipt_project');
    echo "<script>window.open('login_form.php','_self');</script>"; 
?>
