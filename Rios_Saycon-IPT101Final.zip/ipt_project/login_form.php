<?php session_start(); ?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>InspiroSearch</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js"></script>
  <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/js/bootstrap.min.js"></script>
  <style>
    body {
      background-image: url("../ipt_project/bg_color.jpg");
      background-size: cover;
    }
    .login-form {
      width: 340px;
      margin: 50px auto;
      font-size: 15px;
    }
    .login-form form {
      margin-bottom: 15px;
      background: orange;
      box-shadow: 0px 2px 2px rgba(0, 0, 0, 0.3);
      padding: 16px;
    }
    .login-form h2 {
      margin: 20px;
    }
    .form-control, .btn {
      min-height: 38px;
      border-radius: 2px;
    }
    .btn {        
      font-size: 15px;
      font-weight: ;
    }
  </style>
</head>
<body>
  <div class="login-form">
    <form action="" method="post">
      <h2 class="text-center">InspiroSearch</h2>       
      <div class="form-group">
        <input type="text" name="email" class="form-control" placeholder="Email" required="required">
      </div>
      <div class="form-group">
        <input type="password" name="password" class="form-control" placeholder="Password" required="required">
      </div>
      <div class="form-group">
        <input type="submit" name="login-btn" class="btn btn-primary btn-block" value="Login"/>
      </div>    
      <div class="form-group">
      <a href="add_user.php" class="btn btn-secondary btn-block">Sign up</a>
    </div>
    </form>
    
    <?php
      $conn = mysqli_connect('localhost', 'root', '', 'ipt_project');

      if (isset($_POST['login-btn'])) {
      $email = $_POST['email'];
      $password = $_POST['password'];

      $select = "SELECT * FROM web WHERE email = '$email'";
      $run = mysqli_query($conn, $select);
      $row_user = mysqli_fetch_array($run);

        if ($row_user) {
          $db_email = $row_user['email'];
          $db_password = $row_user['password'];

          if ($email == $db_email && $password == $db_password) {
            echo "<script>window.open('index.php', '_self')</script>";
            } else {
            echo "<script>alert('Email or password is incorrect!')</script>";
            }
          } else {
            echo "<script>alert('User not found!')</script>";
          }
        }       
      ?>
      
  </div>
</body>
</html>